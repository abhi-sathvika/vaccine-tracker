export * from "./About";
export * from "./Manage";
export * from "./Home";
export * from "./Dashboard";
export * from "./AddChild";
